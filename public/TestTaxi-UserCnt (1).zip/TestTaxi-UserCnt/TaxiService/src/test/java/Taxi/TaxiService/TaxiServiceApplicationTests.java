package Taxi.TaxiService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
